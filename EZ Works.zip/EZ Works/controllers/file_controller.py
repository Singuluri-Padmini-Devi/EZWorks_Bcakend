import os
from flask import Blueprint, request, jsonify, send_file
from flask_jwt_extended import jwt_required, get_jwt_identity
from models import users_collection
from werkzeug.utils import secure_filename

file_bp = Blueprint('file', __name__)
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'pptx', 'docx', 'xlsx'}

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@file_bp.route('/upload', methods=['POST'])
@jwt_required()
def upload_file():
    user_email = get_jwt_identity()
    user = users_collection.find_one({"email": user_email})
    
    if user['user_type'] != 'ops':
        return jsonify({"message": "Unauthorized"}), 403

    if 'file' not in request.files:
        return jsonify({"message": "No file provided"}), 400

    file = request.files['file']
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        file.save(os.path.join(UPLOAD_FOLDER, filename))
        return jsonify({"message": "File uploaded successfully"})
    return jsonify({"message": "Invalid file type"}), 400

@file_bp.route('/download/<filename>', methods=['GET'])
@jwt_required()
def download_file(filename):
    user_email = get_jwt_identity()
    user = users_collection.find_one({"email": user_email})
    
    if user['user_type'] != 'client':
        return jsonify({"message": "Unauthorized"}), 403

    file_path = os.path.join(UPLOAD_FOLDER, filename)
    if os.path.exists(file_path):
        return send_file(file_path, as_attachment=True)
    return jsonify({"message": "File not found"}), 404
