from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token, jwt_required
from models import create_user, get_user, verify_user
from werkzeug.security import check_password_hash

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/signup', methods=['POST'])
def signup():
    data = request.json
    user = get_user(data['email'])
    if user:
        return jsonify({"message": "User already exists"}), 409

    create_user(data['email'], data['password'], 'client')
    return jsonify({"message": "User registered. Please verify your email."})

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.json
    user = get_user(data['email'])
    if user and check_password_hash(user['password'], data['password']):
        token = create_access_token(identity=user['email'])
        return jsonify({"token": token})
    return jsonify({"message": "Invalid credentials"}), 401

@auth_bp.route('/verify-email', methods=['GET'])
def verify_email():
    email = request.args.get('email')
    verify_user(email)
    return jsonify({"message": "Email verified successfully"})
