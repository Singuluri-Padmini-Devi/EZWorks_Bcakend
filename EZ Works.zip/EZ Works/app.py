from flask import Flask
from flask_jwt_extended import JWTManager
from controllers.auth_controller import auth_bp
from controllers.file_controller import file_bp
from config import Config

app = Flask(__name__)
app.config.from_object(Config)
jwt = JWTManager(app)

app.register_blueprint(auth_bp, url_prefix='/auth')
app.register_blueprint(file_bp, url_prefix='/files')

if __name__ == "__main__":
    app.run(debug=True)
