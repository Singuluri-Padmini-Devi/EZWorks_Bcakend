import hashlib
import hmac
from config import Config

def generate_encrypted_url(filename: str) -> str:
    """Generate an encrypted download link for a file."""
    secret_key = Config.SECRET_KEY.encode()
    message = filename.encode()
    
    # Create a HMAC hash using SHA256
    encrypted_url = hmac.new(secret_key, message, hashlib.sha256).hexdigest()
    return f"/files/download/{encrypted_url}"

def verify_encrypted_url(filename: str, encrypted_url: str) -> bool:
    """Verify if the provided encrypted URL is valid for the filename."""
    expected_url = generate_encrypted_url(filename)
    return hmac.compare_digest(expected_url, encrypted_url)
