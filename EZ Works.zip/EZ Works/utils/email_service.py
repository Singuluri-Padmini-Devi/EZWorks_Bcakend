import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from config import Config

def send_verification_email(to_email: str, verification_link: str):
    """Send an email to verify the user's email address."""
    try:
        msg = MIMEMultipart()
        msg['From'] = Config.EMAIL_USER
        msg['To'] = to_email
        msg['Subject'] = "Verify Your Email Address"
        
        body = f"Click the link below to verify your email:\n{verification_link}"
        msg.attach(MIMEText(body, 'plain'))

        server = smtplib.SMTP(Config.EMAIL_HOST, Config.EMAIL_PORT)
        server.starttls()
        server.login(Config.EMAIL_USER, Config.EMAIL_PASS)
        server.sendmail(Config.EMAIL_USER, to_email, msg.as_string())
        server.quit()

        return True
    except Exception as e:
        print(f"Error sending email: {e}")
        return False
