import pytest
import os
from app import app
from models import users_collection

@pytest.fixture
def client():
    with app.test_client() as client:
        yield client

# Sample Ops user for authentication
ops_user = {
    "email": "opsuser@example.com",
    "password": "securepassword",
    "user_type": "ops",
    "verified": True
}

# Sample Client user for authentication
client_user = {
    "email": "clientuser@example.com",
    "password": "clientpassword",
    "user_type": "client",
    "verified": True
}

def setup_module(module):
    """ Setup the users in the database """
    users_collection.insert_one(ops_user)
    users_collection.insert_one(client_user)

def teardown_module(module):
    """ Cleanup the database after tests """
    users_collection.delete_many({"email": {"$in": [ops_user['email'], client_user['email']]}})
    if os.path.exists('uploads/test_file.xlsx'):
        os.remove('uploads/test_file.xlsx')


def login_user(client, email, password):
    """ Helper function to log in a user and get a token """
    response = client.post('/auth/login', json={
        "email": email,
        "password": password
    })
    return response.json.get("token")


def test_upload_file(client):
    """ Test file upload by Ops user """
    token = login_user(client, ops_user['email'], ops_user['password'])
    headers = {"Authorization": f"Bearer {token}"}

    data = {
        'file': (open('tests/test_file.xlsx', 'rb'), 'test_file.xlsx')
    }
    response = client.post('/files/upload', headers=headers, data=data, content_type='multipart/form-data')
    
    assert response.status_code == 200
    assert response.json['message'] == "File uploaded successfully"


def test_upload_file_unauthorized(client):
    """ Test unauthorized file upload attempt by Client user """
    token = login_user(client, client_user['email'], client_user['password'])
    headers = {"Authorization": f"Bearer {token}"}

    data = {
        'file': (open('tests/test_file.xlsx', 'rb'), 'test_file.xlsx')
    }
    response = client.post('/files/upload', headers=headers, data=data, content_type='multipart/form-data')

    assert response.status_code == 403
    assert response.json['message'] == "Unauthorized"


def test_download_file(client):
    """ Test file download by Client user """
    token = login_user(client, client_user['email'], client_user['password'])
    headers = {"Authorization": f"Bearer {token}"}

    response = client.get('/files/download/test_file.xlsx', headers=headers)
    
    assert response.status_code == 200
    assert response.data is not None


def test_download_file_unauthorized(client):
    """ Test unauthorized file download by Ops user """
    token = login_user(client, ops_user['email'], ops_user['password'])
    headers = {"Authorization": f"Bearer {token}"}

    response = client.get('/files/download/test_file.xlsx', headers=headers)
    
    assert response.status_code == 403
    assert response.json['message'] == "Unauthorized"
