from pymongo import MongoClient
from werkzeug.security import generate_password_hash, check_password_hash
from config import Config

client = MongoClient(Config.MONGO_URI)
db = client['secure_file_db']
users_collection = db['users']

def create_user(email, password, user_type):
    hashed_pw = generate_password_hash(password)
    users_collection.insert_one({
        "email": email,
        "password": hashed_pw,
        "user_type": user_type,
        "verified": False
    })

def get_user(email):
    return users_collection.find_one({"email": email})

def verify_user(email):
    users_collection.update_one({"email": email}, {"$set": {"verified": True}})
